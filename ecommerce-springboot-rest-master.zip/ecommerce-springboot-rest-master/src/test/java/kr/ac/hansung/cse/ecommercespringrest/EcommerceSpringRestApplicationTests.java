package kr.ac.hansung.cse.ecommercespringrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceSpringRestApplicationTests {

    @Test
    void contextLoads() {
    }

}
