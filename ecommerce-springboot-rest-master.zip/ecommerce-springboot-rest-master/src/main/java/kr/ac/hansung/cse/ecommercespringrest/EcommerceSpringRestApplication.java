package kr.ac.hansung.cse.ecommercespringrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceSpringRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(EcommerceSpringRestApplication.class, args);
    }

}
